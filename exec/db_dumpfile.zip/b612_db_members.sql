-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: j8a208.p.ssafy.io    Database: b612_db
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `members`
--

DROP TABLE IF EXISTS `members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `members` (
  `member_id` int NOT NULL AUTO_INCREMENT,
  `member_address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `member_current_score` int NOT NULL DEFAULT '0',
  `member_highest_score` int NOT NULL DEFAULT '0',
  `member_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `member_liked` int NOT NULL DEFAULT '0',
  `member_nickname` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `member_tier_id` int DEFAULT NULL,
  `member_character` int NOT NULL,
  PRIMARY KEY (`member_id`),
  KEY `FKq5repryxghcq9hsdgpu8k02np` (`member_tier_id`),
  CONSTRAINT `FKq5repryxghcq9hsdgpu8k02np` FOREIGN KEY (`member_tier_id`) REFERENCES `tiers` (`tier_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=122 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members`
--

LOCK TABLES `members` WRITE;
/*!40000 ALTER TABLE `members` DISABLE KEYS */;
INSERT INTO `members` VALUES (94,'0x800fc0cacd21c3ec9d65b637ab9afbaa2bc47eec',10,10,'https://firebasestorage.googleapis.com/v0/b/find-your-b612.appspot.com/o/%E1%84%90%E1%85%A9%E1%84%81%E1%85%B5.PNG?alt=media',0,'매끄러운 토깽이 #94',5,3),(100,'0x2903a62a11ecac2f58d0abd1b43087def8bd6f42',72,84,'https://firebasestorage.googleapis.com/v0/b/find-your-b612.appspot.com/o/%E1%84%89%E1%85%A2%E1%86%BC%E1%84%8F%E1%85%B3%E1%84%85%E1%85%B5%E1%86%B7.PNG?alt=media',3,'맑은 생크림 #96',5,4),(104,'0xb31eef3795a8d2c423924a38eec47e5397863b78',15,15,'https://firebasestorage.googleapis.com/v0/b/find-your-b612.appspot.com/o/%E1%84%90%E1%85%A1%E1%86%B7%E1%84%92%E1%85%A5%E1%86%B7%E1%84%80%E1%85%A1.PNG?alt=media',0,'수줍은 여행가 #104',5,3),(106,'0xa1fcd6648c729d09e9f6fe73e6e30b3e56adc01c',6,6,'https://firebasestorage.googleapis.com/v0/b/find-your-b612.appspot.com/o/%E1%84%87%E1%85%B5%E1%84%92%E1%85%A2%E1%86%BC%E1%84%89%E1%85%A1.PNG?alt=media',0,'지혜로운 비행사 #106',4,9),(107,'0x180cfce344192ccf70ff015bc121a9af8ae418d8',0,0,'https://firebasestorage.googleapis.com/v0/b/find-your-b612.appspot.com/o/%E1%84%87%E1%85%B5%E1%84%92%E1%85%A2%E1%86%BC%E1%84%89%E1%85%A1.PNG?alt=media',0,'자유로운 비행사 #107',1,9),(110,'0xb7d9763498e03b69735280488f112dfef0bbb1b4',0,0,'https://firebasestorage.googleapis.com/v0/b/find-your-b612.appspot.com/o/%E1%84%89%E1%85%A2%E1%86%BC%E1%84%8F%E1%85%B3%E1%84%85%E1%85%B5%E1%86%B7.PNG?alt=media',0,'무서운 생크림 #108',1,6),(111,'0x96714bd2760d8ff4c10a913f18fb9b2541577937',3,3,'https://firebasestorage.googleapis.com/v0/b/find-your-b612.appspot.com/o/%E1%84%87%E1%85%A1%E1%84%8F%E1%85%B1.PNG?alt=media',0,'안녕하세요 #111',3,6),(112,'0xbbda11b2b54a5c7b34671bad00cee4b20ec69f96',1,1,'https://firebasestorage.googleapis.com/v0/b/find-your-b612.appspot.com/o/%E1%84%87%E1%85%B5%E1%84%92%E1%85%A2%E1%86%BC%E1%84%89%E1%85%A1.PNG?alt=media',0,'진중한 비행사 #112',2,8),(113,'0xeda5d27c8a536d6299314d7643c339e61c005ee8',0,0,'https://firebasestorage.googleapis.com/v0/b/find-your-b612.appspot.com/o/%E1%84%89%E1%85%A2%E1%86%BC%E1%84%8F%E1%85%B3%E1%84%85%E1%85%B5%E1%86%B7.PNG?alt=media',0,'진실된 생크림 #113',1,2),(114,'0xd64e50bb1fe7c548b425c2aebe8203ac05947429',0,0,'https://firebasestorage.googleapis.com/v0/b/find-your-b612.appspot.com/o/%E1%84%83%E1%85%A1%E1%86%AF%E1%84%91%E1%85%A2%E1%86%BC%E1%84%8B%E1%85%B5.PNG?alt=media',0,'어제 태닝한 달팽이 #114',1,8),(115,'0x511cea19763af6013ed0eb6f0aaa308d4d35c301',0,0,'https://firebasestorage.googleapis.com/v0/b/find-your-b612.appspot.com/o/%E1%84%90%E1%85%A1%E1%86%B7%E1%84%8C%E1%85%A5%E1%86%BC.PNG?alt=media',0,'고귀한 탐정 #115',1,0),(116,'0x511cea19763af6013ed0eb6f0aaa308d4d35c301',0,0,'https://firebasestorage.googleapis.com/v0/b/find-your-b612.appspot.com/o/%E1%84%89%E1%85%A2%E1%86%BC%E1%84%8F%E1%85%B3%E1%84%85%E1%85%B5%E1%86%B7.PNG?alt=media',0,'4월의 벚꽃나무 #115',1,2),(117,'0x4a95a26db7949469ff18a6968277f2afa6ca68f0010bd85949c022f284c4eb27',0,0,'https://firebasestorage.googleapis.com/v0/b/find-your-b612.appspot.com/o/%E1%84%87%E1%85%A1%E1%84%8F%E1%85%B1.PNG?alt=media',0,'부드럽고 따뜻한 바퀴 #117',1,9),(118,'0x7340bdb457138cd48b3951d7a2a622109fa62ac1',0,0,'https://firebasestorage.googleapis.com/v0/b/find-your-b612.appspot.com/o/%E1%84%83%E1%85%A1%E1%86%AF%E1%84%91%E1%85%A2%E1%86%BC%E1%84%8B%E1%85%B5.PNG?alt=media',0,'무서운 달팽이 #118',1,1),(119,'0xc704e2a3c9d7090545ca700211c348070bf1c48b',0,0,'https://firebasestorage.googleapis.com/v0/b/find-your-b612.appspot.com/o/%E1%84%89%E1%85%A2%E1%86%BC%E1%84%8F%E1%85%B3%E1%84%85%E1%85%B5%E1%86%B7.PNG?alt=media',0,'졸린 생크림 #119',1,4),(120,'0x614540203f30c0e2ffa5ba90f643e7d39e1b2600',0,0,'https://firebasestorage.googleapis.com/v0/b/find-your-b612.appspot.com/o/%E1%84%90%E1%85%A9%E1%84%81%E1%85%B5.PNG?alt=media',0,'부자 토깽이 #120',1,6),(121,'0xc6d7583d66fde90f33cdde37ef47450929bbd7a4',0,0,'https://firebasestorage.googleapis.com/v0/b/find-your-b612.appspot.com/o/%E1%84%8C%E1%85%A1%E1%86%B7%E1%84%81%E1%85%AE%E1%84%85%E1%85%A5%E1%84%80%E1%85%B5.PNG?alt=media',0,'돈 잘 갚는 잠꾸러기 #121',1,6);
/*!40000 ALTER TABLE `members` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-07 10:57:27
