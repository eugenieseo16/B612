-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: j8a208.p.ssafy.io    Database: b612_db
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `flowers`
--

DROP TABLE IF EXISTS `flowers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `flowers` (
  `flower_nft_id` int NOT NULL,
  `flower_planted` bit(1) NOT NULL,
  `flower_owner_id` int DEFAULT NULL,
  `created_at` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `flower_type` int NOT NULL,
  `on_sale` bit(1) NOT NULL,
  PRIMARY KEY (`flower_nft_id`),
  KEY `FKo5s0wd3y9l7sccrcjxiuk6kiu` (`flower_owner_id`),
  CONSTRAINT `FKo5s0wd3y9l7sccrcjxiuk6kiu` FOREIGN KEY (`flower_owner_id`) REFERENCES `members` (`member_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flowers`
--

LOCK TABLES `flowers` WRITE;
/*!40000 ALTER TABLE `flowers` DISABLE KEYS */;
INSERT INTO `flowers` VALUES (1,_binary '',100,'1680765612',305,_binary '\0'),(2,_binary '',100,'1680765876',274,_binary '\0'),(3,_binary '',100,'1680767016',631,_binary '\0'),(4,_binary '\0',111,'1680767484',444,_binary '\0'),(5,_binary '',100,'1680769704',668,_binary '\0'),(6,_binary '',100,'1680769728',125,_binary '\0'),(7,_binary '',100,'1680769812',107,_binary '\0'),(8,_binary '',100,'1680769836',331,_binary '\0'),(9,_binary '',112,'1680769848',573,_binary '\0'),(10,_binary '',100,'1680769848',687,_binary '\0'),(11,_binary '',100,'1680769872',140,_binary '\0'),(12,_binary '',100,'1680769896',76,_binary '\0'),(13,_binary '\0',100,'1680769932',403,_binary '\0'),(14,_binary '',106,'1680769956',933,_binary '\0'),(15,_binary '',106,'1680769992',968,_binary '\0'),(16,_binary '',106,'1680770100',129,_binary '\0'),(17,_binary '',106,'1680770124',486,_binary '\0'),(18,_binary '',106,'1680770160',350,_binary '\0'),(19,_binary '\0',100,'1680770172',535,_binary '\0'),(20,_binary '',100,'1680770196',998,_binary '\0'),(21,_binary '',100,'1680770232',990,_binary '\0'),(22,_binary '\0',100,'1680770256',820,_binary '\0'),(23,_binary '',106,'1680770304',466,_binary '\0'),(24,_binary '',106,'1680770352',726,_binary '\0'),(25,_binary '\0',100,'1680770376',988,_binary '\0'),(26,_binary '',100,'1680770412',861,_binary '\0'),(27,_binary '\0',100,'1680770436',527,_binary '\0'),(28,_binary '',100,'1680770460',159,_binary '\0'),(29,_binary '',104,'1680770472',379,_binary '\0'),(30,_binary '',106,'1680770496',562,_binary '\0'),(31,_binary '',106,'1680770592',320,_binary '\0'),(32,_binary '',106,'1680770616',85,_binary '\0'),(33,_binary '',100,'1680770640',99,_binary '\0'),(34,_binary '',104,'1680770652',417,_binary '\0'),(35,_binary '',106,'1680770664',408,_binary '\0'),(36,_binary '',112,'1680770664',606,_binary '\0'),(37,_binary '',100,'1680770676',792,_binary '\0'),(38,_binary '',100,'1680770700',983,_binary '\0'),(39,_binary '\0',100,'1680770712',131,_binary '\0'),(40,_binary '',104,'1680770760',961,_binary '\0'),(41,_binary '',106,'1680770916',650,_binary '\0'),(42,_binary '',106,'1680770964',653,_binary '\0'),(43,_binary '',100,'1680771240',841,_binary '\0'),(44,_binary '\0',100,'1680771264',515,_binary '\0'),(45,_binary '\0',100,'1680771288',558,_binary '\0'),(46,_binary '\0',100,'1680771324',628,_binary '\0'),(47,_binary '',112,'1680783660',135,_binary '\0'),(48,_binary '\0',104,'1680783876',493,_binary '\0'),(49,_binary '\0',104,'1680783888',475,_binary '\0'),(50,_binary '\0',104,'1680783912',205,_binary '\0'),(51,_binary '',104,'1680783960',962,_binary '\0'),(52,_binary '',104,'1680784020',257,_binary '\0'),(53,_binary '\0',104,'1680784032',377,_binary '\0'),(54,_binary '\0',104,'1680784056',406,_binary '\0'),(55,_binary '\0',104,'1680784068',106,_binary '\0'),(56,_binary '',104,'1680784092',486,_binary '\0'),(57,_binary '\0',104,'1680784116',643,_binary '\0'),(58,_binary '\0',104,'1680784140',787,_binary '\0'),(59,_binary '\0',104,'1680784164',272,_binary '\0'),(60,_binary '\0',104,'1680784200',697,_binary '\0'),(61,_binary '',114,'1680784200',875,_binary '\0'),(62,_binary '',114,'1680784212',944,_binary '\0'),(63,_binary '',104,'1680784224',335,_binary '\0'),(64,_binary '',104,'1680784236',579,_binary '\0'),(65,_binary '',104,'1680784260',808,_binary '\0'),(66,_binary '\0',104,'1680784344',445,_binary '\0'),(67,_binary '\0',104,'1680784380',612,_binary '\0'),(68,_binary '\0',104,'1680784452',675,_binary '\0'),(69,_binary '\0',104,'1680784512',46,_binary '\0'),(70,_binary '',104,'1680784548',890,_binary '\0'),(71,_binary '',104,'1680784572',527,_binary '\0'),(72,_binary '\0',104,'1680784584',729,_binary '\0'),(73,_binary '\0',104,'1680784608',595,_binary '\0'),(74,_binary '\0',114,'1680788904',207,_binary '\0'),(75,_binary '',104,'1680789204',360,_binary '\0'),(76,_binary '\0',114,'1680789264',161,_binary '\0'),(77,_binary '',104,'1680795000',300,_binary '\0'),(78,_binary '',104,'1680795552',558,_binary '\0'),(79,_binary '\0',114,'1680796692',833,_binary '\0'),(80,_binary '\0',114,'1680797508',416,_binary '\0'),(81,_binary '\0',114,'1680797664',682,_binary '\0'),(82,_binary '\0',114,'1680797700',405,_binary '\0'),(83,_binary '',114,'1680797784',527,_binary '\0'),(84,_binary '\0',114,'1680797856',530,_binary '\0'),(85,_binary '',114,'1680797880',107,_binary '\0'),(86,_binary '',114,'1680798036',515,_binary '\0'),(87,_binary '\0',114,'1680798144',128,_binary '\0'),(88,_binary '\0',114,'1680798228',134,_binary '\0'),(89,_binary '\0',114,'1680798876',60,_binary '\0'),(90,_binary '\0',114,'1680814116',364,_binary '\0'),(91,_binary '\0',114,'1680814128',441,_binary '\0'),(92,_binary '\0',114,'1680814224',521,_binary '\0'),(93,_binary '\0',114,'1680814272',368,_binary '\0'),(94,_binary '\0',114,'1680814284',331,_binary '\0'),(95,_binary '',114,'1680814308',875,_binary '\0'),(96,_binary '\0',114,'1680814320',835,_binary '\0'),(97,_binary '\0',114,'1680814344',231,_binary '\0'),(98,_binary '\0',114,'1680814428',850,_binary '\0'),(99,_binary '\0',104,'1680829908',170,_binary '\0');
/*!40000 ALTER TABLE `flowers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-07 10:57:30
